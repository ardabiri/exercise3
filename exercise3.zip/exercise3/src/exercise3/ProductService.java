package exercise3;

import java.util.List;
import java.util.stream.Collectors;

public class ProductService {
	private static List<Products> products;
	static {
	Products laptop1 = new Products("laptop-asus", ProductType.digital , 1000 , true);
	Products laptop2 = new Products("laptop-hp", ProductType.digital , 960 , false);
	Products laptop3 = new Products("laptop-dell", ProductType.digital , 950 , false);
	Products mobile1 = new Products("mobile-samsung", ProductType.digital , 400 , true);
	Products mobile2 = new Products("mobile-iphone", ProductType.digital , 600 , true);
	Products mobile3 = new Products("mobile-motorola", ProductType.digital , 300 , false);
	
	Products fridgelg = new Products("fridge-LG", ProductType.khanegi , 500 , false);
	Products fridgesnowa = new Products("fridge-snowa", ProductType.khanegi , 350 , true);
	Products dishwasherbosch = new Products("dishwasher-bosch", ProductType.khanegi , 400 , false);
	Products dishwasherlg = new Products("dishwasher-LG", ProductType.khanegi , 300 , false);
	Products laundry = new Products("laundry-samsung", ProductType.khanegi , 450 , true);
	Products stove = new Products("stove-snowa", ProductType.khanegi , 200 , false);
	
	Products shirtxl = new Products("shirt-XL", ProductType.pushak , 50 , false);
	Products shirtsmall = new Products("shirt-S", ProductType.pushak , 45 , true);
	Products pants = new Products("pants-L", ProductType.pushak , 60 , false);
	Products suit = new Products("suit-XXL", ProductType.pushak , 80 , true);
	Products shoes44 = new Products("shoes-44", ProductType.pushak , 67 , false);
	Products shoes45 = new Products("shoes-45", ProductType.pushak , 70 , true);
	
	products = List.of(laptop1,laptop2,laptop3,mobile1,mobile2,mobile3,fridgelg,fridgesnowa,dishwasherbosch,dishwasherlg,laundry,stove,shirtxl,shirtsmall,pants,suit,shoes44,shoes45);
	
	}
	
	public static List<Products> findproducts(String name, ProductType productType) throws ProductNotFindException{
		List<Products> selectedproducts =  products.stream()
				                                   .filter(t -> t.getName().equals(name)|| t.getProducttype().equals(productType))
				                                   .collect(Collectors.toList());
		if (selectedproducts.size() == 0) {
			return products;
		}
		return selectedproducts;
	} 
}

