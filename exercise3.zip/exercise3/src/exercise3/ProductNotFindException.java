package exercise3;

public class ProductNotFindException extends Exception {

	public ProductNotFindException() {
		// TODO Auto-generated constructor stub
	}

	public ProductNotFindException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductNotFindException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ProductNotFindException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ProductNotFindException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
