package exercise3;



public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		try {
			var name = "laptop-asus";
			var type = ProductType.pushak;
			var foundproducts = ProductService.findproducts(name,type);
			System.out.println(foundproducts.size());
			System.out.println(foundproducts);
		} catch (ProductNotFindException e) {
			// TODO Auto-generated catch block
			System.out.println("product not found!");
		}
		
	}
	
	
	

}
