package exercise3;

public class Products {
	private String name;
	private ProductType producttype;
	private int price;
	private boolean hasoffer;
	
	
	public Products(String name, ProductType producttype, int price, boolean hasoffer) {
		super();
		this.name = name;
		this.producttype = producttype;
		this.price = price;
		this.hasoffer = hasoffer;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ProductType getProducttype() {
		return producttype;
	}
	public void setProducttype(ProductType producttype) {
		this.producttype = producttype;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public boolean isHasoffer() {
		return hasoffer;
	}
	public void setHasoffer(boolean hasoffer) {
		this.hasoffer = hasoffer;
	}

	@Override
	public String toString() {
		return "Products [name=" + name + ", producttype=" + producttype + ", price=" + price + ", hasoffer=" + hasoffer
				+ "]";
	}
	

}
