package exercise3;

public enum ProductType {
	digital,pushak,khanegi,toys;
}
